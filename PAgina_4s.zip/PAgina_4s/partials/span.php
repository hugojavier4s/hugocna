contacto.php<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="estilos/indexestilos.css">

	<link rel="stylesheet" href="fonts.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
<!--<script src="js/jquery.easydropdown.js"></script>-->
<!--start slider -->
<link rel="stylesheet" href="css/fwslider.css" media="all">
<script src="js/jquery-ui.min.js"></script>
<script src="js/fwslider.js"></script>
<!--end slider -->
<script type="text/javascript">
        $(document).ready(function() {
            $(".dropdown img.flag").addClass("flagvisibility");

            $(".dropdown dt a").click(function() {
                $(".dropdown dd ul").toggle();
            });
                        
            $(".dropdown dd ul li a").click(function() {
                var text = $(this).html();
                $(".dropdown dt a span").html(text);
                $(".dropdown dd ul").hide();
                $("#result").html("Selected value is: " + getSelectedValue("sample"));
            });
                        
            function getSelectedValue(id) {
                return $("#" + id).find("dt a span.value").html();
            }

            $(document).bind('click', function(e) {
                var $clicked = $(e.target);
                if (! $clicked.parents().hasClass("dropdown"))
                    $(".dropdown dd ul").hide();
            });


            $("#flagSwitcher").click(function() {
                $(".dropdown img.flag").toggleClass("flagvisibility");
            });
        });
     </script>
</head>
<body>
  
<div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Sobre nosotros</h4>
              <p style="color:white">Somos un equipo el cual esta cargo de toda la comunidad que le guste cocinar. esta proyecto se ha echo con la finalidad de que todos vosotros aprendamos a cocinar facil, rico y saludable. </p>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Enlaces rápidos</h4>
              <li><a href="recetas.php">Comida</a></li>
              <li><a href="#">Snacks</a></li>
              <li><a href="contacto.php">Contacto</a></li>
              <li><a href="reglas.php">Reglas de comunidad</a></li>
            </ul>
          </div>
         
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Visita nuestro canal de YouTube</h4>
              <p style="color:white">Para disfrutar de multiples recetas que les ayudaran a mejorar en la cocina.</p>
              <li><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured">Click para ir al canal</a></li>
              <ul class="social"> 
                <li class="facebook"><a href="#"><span> </span></a></li>
                <li class="twitter"><a href="#"><span> </span></a></li>
                <li class="instagram"><a href="#"><span> </span></a></li> 
                <li class="pinterest"><a href="#"><span> </span></a></li> 
                <li class="youtube"><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured"><span> </span></a></li>                             
                </ul>
                
            </ul>
          </div>
        </div>
        <div class="row footer_bottom">
            <div class="copy">
                 <p>© 2020 Template by <a href="https://www.facebook.com/javier.landa.96343" target="_blank">LANDITA</a></p>
                </div>
            
          </div>
      </div>
    </div>

</body>
</html>