<?php
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE id = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="estilos/indexestilos.css">

	<link rel="stylesheet" href="fonts.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
<!--<script src="js/jquery.easydropdown.js"></script>-->
<!--start slider -->
<link rel="stylesheet" href="css/fwslider.css" media="all">
<script src="js/jquery-ui.min.js"></script>
<script src="js/fwslider.js"></script>
<!--end slider -->
<script type="text/javascript">
        $(document).ready(function() {
            $(".dropdown img.flag").addClass("flagvisibility");

            $(".dropdown dt a").click(function() {
                $(".dropdown dd ul").toggle();
            });
                        
            $(".dropdown dd ul li a").click(function() {
                var text = $(this).html();
                $(".dropdown dt a span").html(text);
                $(".dropdown dd ul").hide();
                $("#result").html("Selected value is: " + getSelectedValue("sample"));
            });
                        
            function getSelectedValue(id) {
                return $("#" + id).find("dt a span.value").html();
            }

            $(document).bind('click', function(e) {
                var $clicked = $(e.target);
                if (! $clicked.parents().hasClass("dropdown"))
                    $(".dropdown dd ul").hide();
            });


            $("#flagSwitcher").click(function() {
                $(".dropdown img.flag").toggleClass("flagvisibility");
            });
        });
     </script>
</head>
<body>

  <div class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
         <div class="header-left">
           <div class="logo">
            <a href="index.html"><img src="images/logo.jpg" alt=""/></a>
           </div>
           <div class="menu">
              <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
                <ul class="nav" id="nav">
                  <li><a href="index.php">Inicio</a></li>
                  <li><a href="recetas.php">Recetas</a></li>
                  <li><a href="videos.php">Videos</a></li>
                <li><a href="contacto.php">Contacto</a></li> 
                   
      <div class="clear"></div>
              </ul>

              <script type="text/javascript" src="js/responsive-nav.js"></script>
            </div>              
              <div class="clear"></div>
            </div>
              <div class="header_right">

        
            <script src="js/classie.js"></script>
            <script src="js/uisearch.js"></script>
            <script>
              new UISearch( document.getElementById( 'sb-search' ) );
            </script>
            
            <ul class="icon1 sub-icon1 profile_img">
           <li><a class="active-icon c1" href="#"> </a>
            <ul class="sub-icon1 list">
               <div class="clear"></div>
              <div class="login_buttons">
                <?php if(!empty($user)): ?><br>
      <li><a href=""> <?= $user['email']; ?></a></li>
      
      <li><a href="logout.php">
        cerrar sesión
      </a></li>
    <li><?php else: ?>
      <h1></h1>

      <a href="login.php">Iniciar Sesión   |  </a> 
    <a href="signup.php">  Registrarse</a>
    <?php endif; ?>   
              </div>
              <div class="clear"></div>
            </ul>
           </li>
           </ul>
               <div class="clear"></div>
         </div>
        </div>
     </div>
      </div>
  </div>
  <div class="banner">
  <!-- start slider -->
       <div id="fwslider">
         <div class="slider_container">
            <div class="slide"> 
                <!-- Slide image -->
               <img src="images/r1.jpg" class="img-responsive" alt=""/>
            
                <!-- Texts container -->
                <div class="slide_content">
                    <div class="slide_content_wrap">
            
                        <div class="button"><a href="#">Da click para mas información</a></div>
                    </div>
                </div>
               <!-- /Texts container -->
            </div>
            <div class="slide"> 
                <!-- Slide image -->
               <img src="images/r3.jpg" class="img-responsive" alt=""/>
                <!-- /Slide image -->
                <!-- Texts container -->
                <div class="slide_content">
                    <div class="slide_content_wrap">
            
                        <div class="button"><a href="#">Da click para mas información</a></div>
                    </div>
                </div>
               <!-- /Texts container -->
            </div>
            <!-- /Duplicate to create more slides -->
            
        <div class="timers"></div>
        <div class="slidePrev"><span></span></div>
        <div class="slideNext"><span></span></div>
       </div>
       <!--/slider -->
      </div>
<div class="timers"></div>
        <div class="slidePrev"><span></span></div>
        <div class="slideNext"><span></span></div>
       </div>
       <!--/slider -->
      </div>
    <div class="main">
    <div class="content-top"><br>
      <h2>Aprende a cocinar con nosotros</h2>
        <ul id="flexiselDemo3">
        <li><br><img src="images/c1.jpg"/></li>
        <li><br><img src="images/c5.jpg"/></li>
        <li><br><img src="images/c3.jpg"/></li>
        <li><br><img src="images/c4.jpg"/></li>
        <li><br><img src="images/c5.jpg"/></li>
        <li><br><img src="images/c6.jpg"/></li>
        <li><br><img src="images/c7.jpg"/></li>
        <li><br><img src="images/c8.jpg"/></li>
        <li><br><img src="images/c9.jpg"/></li>
      </ul>
      <script type="text/javascript">
    $(window).load(function() {
      $("#flexiselDemo3").flexisel({
        visibleItems: 5,
        animationSpeed: 1500,
        autoPlay: true,
        autoPlaySpeed: 3000,        
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
          responsiveBreakpoints: { 
            portrait: { 
              changePoint:480,
              visibleItems: 1
            }, 
            landscape: { 
              changePoint:640,
              visibleItems: 2
            },
            tablet: { 
              changePoint:768,
              visibleItems: 3
            }
          }
        });
        
    });
    </script>
    <script type="text/javascript" src="js/jquery.flexisel.js"></script>
    </div>
  </div>
  <div class="content-bottom">
    <div class="container">
      <div class="row content_bottom-text">
        <div class="col-md-7">

        <h3>Aprende a cocinar <br>con Hugo</h3>
        <p class="m_1">Esté sitió web fue creado con el fin de compartir mis recetas que hago día a día. Compartiendo mis postres,comidas,snacks,tanto FAT como FIT </p>
        <p class="m_2">Muchas gracias por entrar al sitió web , recuerda compartir nuestros videos y recomendarlos así llegaremos a saber si les gusta nuestro contenido (recetas) y seguir con nuestro proyecto. Un cordial saludo -Hugo.</p>
        </div>
      </div>
    </div>
  </div>
  <div class="features">
    <div class="container">
      <h3 class="m_3">Recetas Destacadas</h3>
      <div class="close_but"><i class="close1"> </i></div>
        <div class="row">
        <div class="col-md-3 top_box">
          <div class="view view-ninth"><a href="#">
                    <img src="images/n1.jpg" class="img-responsive" alt=""/>
                    <div class="mask mask-1"> </div>
                    <div class="mask mask-2"> </div>
                      <div class="content">
                        <h2>Mejor receta #1</h2>
                        <p>click para ír...</p>
                      </div>
                   </a> </div
                  </div>
                  <h4 class="m_4"><a href="#">Pollo en salsa verde.</a></h4>
                  <p class="m_5">Cocina con Hugo.</p>
                </div>
                <div class="col-md-3 top_box">
          <div class="view view-ninth"><a href="#">
                    <img src="images/n2.jpg" class="img-responsive" alt=""/>
                    <div class="mask mask-1"> </div>
                    <div class="mask mask-2"> </div>
                      <div class="content">
                        <h2>Mejor receta #2</h2>
                        <p>Click para ír...</p>
                      </div>
                    </a> </div>
                   <h4 class="m_4"><a href="#">Pozole</a></h4>
                   <p class="m_5">Cocina con Hugo</p>
        </div>
        <div class="col-md-3 top_box">
          <div class="view view-ninth"><a href="#">
                    <img src="images/n3.jpg" class="img-responsive" alt=""/>
                    <div class="mask mask-1"> </div>
                    <div class="mask mask-2"> </div>
                      <div class="content">
                        <h2>Mejor Receta #3</h2>
                        <p>Click para ír...</p>
                      </div>
                    </a> </div>
                   <h4 class="m_4"><a href="#">Mole</a></h4>
                   <p class="m_5">Cocina con Hugo</p>
        </div>
        <div class="col-md-3 top_box1">
          <div class="view view-ninth"><a href="#">
                    <img src="images/n4.jpg" class="img-responsive" alt=""/>
                    <div class="mask mask-1"> </div>
                    <div class="mask mask-2"> </div>
                      <div class="content">
                        <h2>Mejor receta #4</h2>
                        <p>Click para ír...</p>
                      </div>
                     </a> </div>
                   <h4 class="m_4"><a href="#">Tamales</a></h4>
                   <p class="m_5">Cocina con Hugo</p>
        </div>
      </div>
     </div>
      </div>
<div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Sobre nosotros</h4>
              <p style="color:white">Somos un equipo el cual esta cargo de toda la comunidad que le guste cocinar. esta proyecto se ha echo con la finalidad de que todos vosotros aprendamos a cocinar facil, rico y saludable. </p>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Enlaces rápidos</h4>
              <li><a href="videos.php">Comida</a></li>
              <li><a href="#">Snacks</a></li>
              <li><a href="contacto.php">Contacto</a></li>
              <li><a href="reglas.php">Reglas de comunidad</a></li>
            </ul>
          </div>
         
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Visita nuestro canal de YouTube</h4>
              <p style="color:white">Para disfrutar de multiples recetas que les ayudaran a mejorar en la cocina.</p>
              <li><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured">Click para ir al canal</a></li>
              <ul class="social"> 
                <li class="facebook"><a href="#"><span> </span></a></li>
                <li class="twitter"><a href="#"><span> </span></a></li>
                <li class="instagram"><a href="#"><span> </span></a></li> 
                <li class="pinterest"><a href="#"><span> </span></a></li> 
                <li class="youtube"><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured"><span> </span></a></li>                             
                </ul>
                
            </ul>
          </div>
        </div>
        <div class="row footer_bottom">
            <div class="copy">
                 <p>© 2020 Template by <a href="https://www.facebook.com/javier.landa.96343" target="_blank">LANDITA</a></p>
                </div>
            
          </div>
      </div>
    </div>

</body>
</html>