<?php
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE id = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="estilos/indexestilos.css">

	<link rel="stylesheet" href="fonts.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
<!--<script src="js/jquery.easydropdown.js"></script>-->
<!--start slider -->
<link rel="stylesheet" href="css/fwslider.css" media="all">
<script src="js/jquery-ui.min.js"></script>
<script src="js/fwslider.js"></script>

</head>
<body>

  <div class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
         <div class="header-left">
           <div class="logo">
            <a href="index.html"><img src="images/logo.jpg" alt=""/></a>
           </div>
           <div class="menu">
              <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
                <ul class="nav" id="nav">
                  <li><a href="index.php">Inicio</a></li>
                  <li><a href="recetas.php">Recetas</a></li>
                  <li><a href="videos.php">Videos</a></li>
                <li><a href="contacto.php">Contacto</a></li> 
                   
      <div class="clear"></div>
              </ul>

              <script type="text/javascript" src="js/responsive-nav.js"></script>
            </div>              
              <div class="clear"></div>
            </div>
              <div class="header_right">

        
            <script src="js/classie.js"></script>
            <script src="js/uisearch.js"></script>
            <script>
              new UISearch( document.getElementById( 'sb-search' ) );
            </script>
            
            <ul class="icon1 sub-icon1 profile_img">
           <li><a class="active-icon c1" href="#"> </a>
            <ul class="sub-icon1 list">
               <div class="clear"></div>
              <div class="login_buttons">
                <?php if(!empty($user)): ?><br>
      <li><a href=""> <?= $user['email']; ?></a></li>
      
      <li><a href="logout.php">
        cerrar sesión
      </a></li>
    <li><?php else: ?>
      <h1></h1>

      <a href="login.php">Iniciar Sesión   |  </a> 
    <a href="signup.php">  Registrarse</a>
    <?php endif; ?>   
              </div>
              <div class="clear"></div>
            </ul>
           </li>
           </ul>
               <div class="clear"></div>
         </div>
        </div>
     </div>
      </div>
  </div>
<div class="article-header">
					<h1 style="color:red">
				Receta de Enchiladas Verdes			</h1>
						<a href="https://www.youtube.com/watch?v=pMsxmh3CaH8&t=14s"><img  src="images/e2.jpg" style="float:left; width:300; height:200px;" ></a>	<br><br>	<br><br><br><br><br><br><br>
			</div>
	
	<div >
		<p style="text-align: justify;">Estas enchiladas, aunque su nombre nos haga parecer lo contrario, son muy mexicanas y una de las variedades de enchilada que más sabor tienen por ofrecer Sigue leyendo la receta y entérate de qué se necesita para preparar tan delicioso platillo.</p>

<p style="text-align: justify;  color: red"><strong><b>Ingredientes:</b></strong></p>
<ul style="text-align: justify;">
<li>1 kilo de pechuga de pollo</li>
<li>½ kilo de tomate verde</li>
<li>¼ de kilo de cebolla</li>
<li>3 dientes de ajo</li>
<li>3 chiles Jalapeño verdes</li>  
<li>½ taza de caldo de pollo</li>
<li>1 kilo de tortilla</li>
<li>2 tazas de aceite</li>
<li>Sal al gusto</li>
<li>Pimienta al gusto</li>
</ul>
<p style="text-align: justify; color:red"><strong><b>Instrucciones:</b></strong></p>
<ul>
<li style="text-align: justify;"><strong><b>Para la preparación de la salsa: </b></strong>se hierven los tomates y chiles. Posteriormente, se licúan con la cebolla, el ajo y el caldo de pollo. </li>
<li style="text-align: justify;">En una olla se agrega el aceite y se sofríe la salsa con un toque de sal y pimienta. Cocinar la salsa hasta que espese ligeramente y dejar reposar.</li>
<li style="text-align: justify;">Posteriormente se preparan las tortillas, para ello se coloca al centro de cada tortilla un poco de pollo cocido.</li>
<li style="text-align: justify;">Después se envuelve la tortilla formando un taco, se acomodan en un plato de 3 a 4 tortillas rellenas de pollo y se baña con la salsa.</li>
<li style="text-align: justify;">Para decorar se sirve y acompaña con más salsa, crema y cebolla.</li>
</ul>
<p> </p>	</div>
<div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Sobre nosotros</h4>
              <p style="color:white">Somos un equipo el cual esta cargo de toda la comunidad que le guste cocinar. esta proyecto se ha echo con la finalidad de que todos vosotros aprendamos a cocinar facil, rico y saludable. </p>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Enlaces rápidos</h4>
              <li><a href="videos.php">Comida</a></li>
              <li><a href="#">Snacks</a></li>
              <li><a href="contacto.php">Contacto</a></li>
              <li><a href="reglas.php">Reglas de comunidad</a></li>
            </ul>
          </div>
         
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Visita nuestro canal de YouTube</h4>
              <p style="color:white">Para disfrutar de multiples recetas que les ayudaran a mejorar en la cocina.</p>
              <li><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured">Click para ir al canal</a></li>
              <ul class="social"> 
                <li class="facebook"><a href="#"><span> </span></a></li>
                <li class="twitter"><a href="#"><span> </span></a></li>
                <li class="instagram"><a href="#"><span> </span></a></li> 
                <li class="pinterest"><a href="#"><span> </span></a></li> 
                <li class="youtube"><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured"><span> </span></a></li>                             
                </ul>
                
            </ul>
          </div>
        </div>
        <div class="row footer_bottom">
            <div class="copy">
                 <p>© 2020 Template by <a href="https://www.facebook.com/javier.landa.96343" target="_blank">LANDITA</a></p>
                </div>
            
          </div>
      </div>
    </div>

</body>
</html>