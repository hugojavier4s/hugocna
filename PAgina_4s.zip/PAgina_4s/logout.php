<?php
  session_start();

  session_unset();

  session_destroy();

  header('Location: /PAgina_4s/index.php');
?>
