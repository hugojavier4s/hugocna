<?php
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE id = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="estilos/indexestilos.css">

	<link rel="stylesheet" href="fonts.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
<!--<script src="js/jquery.easydropdown.js"></script>-->
<!--start slider -->
<link rel="stylesheet" href="css/fwslider.css" media="all">
<script src="js/jquery-ui.min.js"></script>
<script src="js/fwslider.js"></script>
<!--end slider -->
<script type="text/javascript">
        $(document).ready(function() {
            $(".dropdown img.flag").addClass("flagvisibility");

            $(".dropdown dt a").click(function() {
                $(".dropdown dd ul").toggle();
            });
                        
            $(".dropdown dd ul li a").click(function() {
                var text = $(this).html();
                $(".dropdown dt a span").html(text);
                $(".dropdown dd ul").hide();
                $("#result").html("Selected value is: " + getSelectedValue("sample"));
            });
                        
            function getSelectedValue(id) {
                return $("#" + id).find("dt a span.value").html();
            }

            $(document).bind('click', function(e) {
                var $clicked = $(e.target);
                if (! $clicked.parents().hasClass("dropdown"))
                    $(".dropdown dd ul").hide();
            });


            $("#flagSwitcher").click(function() {
                $(".dropdown img.flag").toggleClass("flagvisibility");
            });
        });
     </script>
</head>
<body>

  <div class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
         <div class="header-left">
           <div class="logo">
            <a href="index.html"><img src="images/logo.jpg" alt=""/></a>
           </div>
           <div class="menu">
              <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
                <ul class="nav" id="nav">
                  <li><a href="index.php">Inicio</a></li>
                  <li><a href="recetas.php">Recetas</a></li>
                  <li><a href="videos.php">Videos</a></li>
                <li><a href="contacto.php">Contacto</a></li> 
                   
      <div class="clear"></div>
              </ul>

              <script type="text/javascript" src="js/responsive-nav.js"></script>
            </div>              
              <div class="clear"></div>
            </div>
              <div class="header_right">

        
            <script src="js/classie.js"></script>
            <script src="js/uisearch.js"></script>
            <script>
              new UISearch( document.getElementById( 'sb-search' ) );
            </script>
            
            <ul class="icon1 sub-icon1 profile_img">
           <li><a class="active-icon c1" href="#"> </a>
            <ul class="sub-icon1 list">
               <div class="clear"></div>
              <div class="login_buttons">
                <?php if(!empty($user)): ?><br>
      <li><a href=""> <?= $user['email']; ?></a></li>
      
      <li><a href="logout.php">
        cerrar sesión
      </a></li>
    <li><?php else: ?>
      <h1></h1>

      <a href="login.php">Iniciar Sesión   |  </a> 
    <a href="signup.php">  Registrarse</a>
    <?php endif; ?>   
              </div>
              <div class="clear"></div>
            </ul>
           </li>
           </ul>
               <div class="clear"></div>
         </div>
        </div>
     </div>
      </div>
  </div>
     <div class="main">
      <div class="shop_top">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
				  <div class="map">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3775.5802575837783!2d-99.24700278562635!3d18.86132226358783!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85cdd834f882592d%3A0xa1a512dde86002a3!2sINEA%20tetecala!5e0!3m2!1ses!2smx!4v1590345626531!5m2!1ses!2smx" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
				  </div>
				</div>
				<div class="col-md-5">
					<p class="m_8">Bienvenido a la página de contanco, por esta página te podras mantener en contaco con nosotros cualquier duda te la resolveremos lo mas rápido posible. Queremos lo mejor para nuestra comunidad y cualquier duda o sugerencia estamos para resolverla en cualquier momento.</p>
					<div class="address">
				                <p>Privada alta tensión,</p>
						   		<p>numero 7,colonia Temixco Morelos,</p>
						   		<p>Cuernavaca</p>
				   		<p>teléfono:(+52) 561 043 4080</p>
				 	 	<p>Correo: <span>hugolanda420@gmail.com</span></p>
				   		<p>Seguirnos en: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 contact">
				  <form method="post" action="contact-post.html">
					<div class="to">
                     	<input type="text" class="text" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}">
					 	<input type="text" class="text" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}">
					 	<input type="text" class="text" value="Subject" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Subject';}">
					</div>
					<div class="text">
	                   <textarea value="Message:" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message';}">Message:</textarea>
	                   <div class="form-submit">
			           <input name="submit" type="submit" id="submit" value="Submit"><br>
			           </div>
	                </div>
	                <div class="clear"></div>
                   </form>
			     </div>
		    </div>
	     </div>
	   </div>
	  </div>
	     <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Sobre nosotros</h4>
              <p style="color:white">Somos un equipo el cual esta cargo de toda la comunidad que le guste cocinar. esta proyecto se ha echo con la finalidad de que todos vosotros aprendamos a cocinar facil, rico y saludable. </p>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Enlaces rápidos</h4>
              <li><a href="recetas.php">Comida</a></li>
              <li><a href="#">Snacks</a></li>
              <li><a href="contacto.php">Contacto</a></li>
              <li><a href="reglas.php">Reglas de comunidad</a></li>
            </ul>
          </div>
         
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Visita nuestro canal de YouTube</h4>
              <p style="color:white">Para disfrutar de multiples recetas que les ayudaran a mejorar en la cocina.</p>
              <li><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured">Click para ir al canal</a></li>
              <ul class="social"> 
                <li class="facebook"><a href="#"><span> </span></a></li>
                <li class="twitter"><a href="#"><span> </span></a></li>
                <li class="instagram"><a href="#"><span> </span></a></li> 
                <li class="pinterest"><a href="#"><span> </span></a></li> 
                <li class="youtube"><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured"><span> </span></a></li>                             
                </ul>
                
            </ul>
          </div>
        </div>
        <div class="row footer_bottom">
            <div class="copy">
                 <p>© 2020 Template by <a href="https://www.facebook.com/javier.landa.96343" target="_blank">LANDITA</a></p>
                </div>
            
          </div>
      </div>
    </div>

</body>	
</html>