<?php
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE id = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" href="estilos/indexestilos.css">

  <link rel="stylesheet" href="fonts.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
<!--<script src="js/jquery.easydropdown.js"></script>-->
<!--start slider -->
<link rel="stylesheet" href="css/fwslider.css" media="all">
<script src="js/jquery-ui.min.js"></script>
<script src="js/fwslider.js"></script>

</head>
<body>

  <div class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
         <div class="header-left">
           <div class="logo">
            <a href="index.html"><img src="images/logo.jpg" alt=""/></a>
           </div>
           <div class="menu">
              <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
                <ul class="nav" id="nav">
                  <li><a href="index.php">Inicio</a></li>
                  <li><a href="recetas.php">Recetas</a></li>
                  <li><a href="videos.php">Videos</a></li>
                <li><a href="contacto.php">Contacto</a></li> 
                   
      <div class="clear"></div>
              </ul>

              <script type="text/javascript" src="js/responsive-nav.js"></script>
            </div>              
              <div class="clear"></div>
            </div>
              <div class="header_right">

        
            <script src="js/classie.js"></script>
            <script src="js/uisearch.js"></script>
            <script>
              new UISearch( document.getElementById( 'sb-search' ) );
            </script>
            
            <ul class="icon1 sub-icon1 profile_img">
           <li><a class="active-icon c1" href="#"> </a>
            <ul class="sub-icon1 list">
               <div class="clear"></div>
              <div class="login_buttons">
                <?php if(!empty($user)): ?><br>
      <li><a href=""> <?= $user['email']; ?></a></li>
      
      <li><a href="logout.php">
        cerrar sesión
      </a></li>
    <li><?php else: ?>
      <h1></h1>

      <a href="login.php">Iniciar Sesión   |  </a> 
    <a href="signup.php">  Registrarse</a>
    <?php endif; ?>   
              </div>
              <div class="clear"></div>
            </ul>
           </li>
           </ul>
               <div class="clear"></div>
         </div>
        </div>
     </div>
      </div>
  </div>
<div class="article-header">
          <h1 style="color:red">
        Receta de Chiles Rellenos     </h1>
            <a href="https://www.youtube.com/watch?v=pMsxmh3CaH8&t=8s"><img  src="images/e1.jpg" style="float:left; width:300; height:200px;" ></a>  <br><br>  <br><br><br><br><br><br><br>
      </div>
  
  <div >

<p style="text-align: justify;  color: red"><strong><b>Ingredientes:</b></strong></p>
<ul style="text-align: justify;">
<li>5 Piezas Chile poblano pelados y desvenados</li>
<li>200 Gramos Queso Panela cortados en tiras</li>
<li>3 Piezas Clara de huevo</li>
<li>1 Taza Harina de trigo</li>
<li>3 Piezas Yema</li>
<li>1/2 Taza Aceite  para freír</li>
<li>3 Piezas Jitomate</li>
<li>1/4 Taza Puré de tomate</li>
<li>1 Taza Agua</li>
<li>2 Cubos Concentrado de Tomate con Pollo CONSOMATE®</li>
</ul>
<p style="text-align: justify; color:red"><strong><b>Instrucciones:</b></strong></p>
<ul>
<li style="text-align: justify;"><strong><b>Relleno: </b></strong> Rellena cada chile con 2 cucharadas de frijoles y con rebanadas de queso, ciérralos con un palillo para evitar que se salga el relleno; pásalos por la harina y reserva.</li>
<li style="text-align: justify;"><strong><b>Licúar y freír: </b></strong> Para el caldillo, licua los jitomates, el agua, el Concentrado de Tomate con Pollo CONSOMATE® y el Orégano; cuela. En una cacerola calienta las dos cucharadas de aceite y fríe por 10 minutos o hasta que hierva.

</li>
<li style="text-align: justify;"><strong><b>Batir y freír</b></strong> : Por último, bate las claras hasta formar picos duros y agrega las yemas una por una sin dejar de batir; pasa los chiles por el capeado y fríelos en aceite caliente. Escurre sobre papel absorbente y pásalos al caldillo; sirve y ofrece.</li>

</ul>
<p> </p>  </div>
<div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Sobre nosotros</h4>
              <p style="color:white">Somos un equipo el cual esta cargo de toda la comunidad que le guste cocinar. esta proyecto se ha echo con la finalidad de que todos vosotros aprendamos a cocinar facil, rico y saludable. </p>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Enlaces rápidos</h4>
              <li><a href="videos.php">Comida</a></li>
              <li><a href="#">Snacks</a></li>
              <li><a href="contacto.php">Contacto</a></li>
              <li><a href="reglas.php">Reglas de comunidad</a></li>
            </ul>
          </div>
         
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Visita nuestro canal de YouTube</h4>
              <p style="color:white">Para disfrutar de multiples recetas que les ayudaran a mejorar en la cocina.</p>
              <li><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured">Click para ir al canal</a></li>
              <ul class="social"> 
                <li class="facebook"><a href="#"><span> </span></a></li>
                <li class="twitter"><a href="#"><span> </span></a></li>
                <li class="instagram"><a href="#"><span> </span></a></li> 
                <li class="pinterest"><a href="#"><span> </span></a></li> 
                <li class="youtube"><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured"><span> </span></a></li>                             
                </ul>
                
            </ul>
          </div>
        </div>
        <div class="row footer_bottom">
            <div class="copy">
                 <p>© 2020 Template by <a href="https://www.facebook.com/javier.landa.96343" target="_blank">LANDITA</a></p>
                </div>
            
          </div>
      </div>
    </div>

</body>
</html>