<?php
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE id = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Videos</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
<script type="text/javascript">
        $(document).ready(function() {
            $(".dropdown img.flag").addClass("flagvisibility");

            $(".dropdown dt a").click(function() {
                $(".dropdown dd ul").toggle();
            });
                        
            $(".dropdown dd ul li a").click(function() {
                var text = $(this).html();
                $(".dropdown dt a span").html(text);
                $(".dropdown dd ul").hide();
                $("#result").html("Selected value is: " + getSelectedValue("sample"));
            });
                        
            function getSelectedValue(id) {
                return $("#" + id).find("dt a span.value").html();
            }

            $(document).bind('click', function(e) {
                var $clicked = $(e.target);
                if (! $clicked.parents().hasClass("dropdown"))
                    $(".dropdown dd ul").hide();
            });


            $("#flagSwitcher").click(function() {
                $(".dropdown img.flag").toggleClass("flagvisibility");
            });
        });
     </script>
    <!-- light-box -->
	<script type="text/javascript" src="js/jquery.fancybox.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css" media="screen" />
   <script type="text/javascript">
		$(document).ready(function() {
			

			$('.fancybox').fancybox();

		});
	</script>
</head>
<body>
	 <div class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
         <div class="header-left">
           <div class="logo">
            <a href="index.html"><img src="images/logo.jpg" alt=""/></a>
           </div>
           <div class="menu">
              <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
                <ul class="nav" id="nav">
                  <li><a href="index.php">Inicio</a></li>
                  <li><a href="recetas.php">Recetas</a></li>
                  <li><a href="videos.php">Videos</a></li>
                <li><a href="contacto.php">Contacto</a></li> 
                   
      <div class="clear"></div>
              </ul>

              <script type="text/javascript" src="js/responsive-nav.js"></script>
            </div>              
              <div class="clear"></div>
            </div>
              <div class="header_right">

        
            <script src="js/classie.js"></script>
            <script src="js/uisearch.js"></script>
            <script>
              new UISearch( document.getElementById( 'sb-search' ) );
            </script>
            
            <ul class="icon1 sub-icon1 profile_img">
           <li><a class="active-icon c1" href="#"> </a>
            <ul class="sub-icon1 list">
               <div class="clear"></div>
              <div class="login_buttons">
                <?php if(!empty($user)): ?><br>
      <li><a href=""> <?= $user['email']; ?></a></li>
      
      <li><a href="logout.php">
        cerrar sesión
      </a></li>
    <li><?php else: ?>
      <h1></h1>

      <a href="login.php">Iniciar Sesión   |  </a> 
    <a href="signup.php">  Registrarse</a>
    <?php endif; ?>   
              </div>
              <div class="clear"></div>
            </ul>
           </li>
           </ul>
               <div class="clear"></div>
         </div>
        </div>
     </div>
      </div>
  </div>
     <div class="main">
      <div class="shop_top">
		<div class="container">
			<div class="row ex_box">
				<h3 class="m_2"">Videos</h3>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/e1.jpg" data-fancybox-group="gallery" title="Animate a hacerla"><img src="images/e1.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						<a href="chiles.php" >Chiles rellenos</a>
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/e2.jpg" data-fancybox-group="gallery" title="Animate a hacerla"><img src="images/e2.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						<a href="enchiladas.php" >Enchiladas verdes</a>
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/e3.jpg" data-fancybox-group="gallery" title="Animate a hacerla"><img src="images/e3.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						En proceso.....
					</div>
				</a></div>
				</div>
		    </div>
		    <div class="row ex_box">
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/e4.jpg" data-fancybox-group="gallery" title="Animate a hacerla"><img src="images/e4.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						En proceso.....
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/e5.jpg" data-fancybox-group="gallery" title="Animate a hacerla"><img src="images/e5.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						En proceso.....
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/e6.jpg" data-fancybox-group="gallery" title="Animate a hacerla"><img src="images/e6.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						En proceso.....
					</div>
				</a></div>
				</div>
		    </div>
		    <div class="row ex1_box">
			   <div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/e7.jpg" data-fancybox-group="gallery" title="Animate a hacerla"><img src="images/e7.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						En proceso.....
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/e8.jpg" data-fancybox-group="gallery" title="Animate a hacerla"><img src="images/e8.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						En proceso.....
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/e9.jpg" data-fancybox-group="gallery" title="Animate a hacerla"><img src="images/e9.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						En proceso.....
					</div>
				</a></div>
			   </div>
		    </div>
		 </div>
	   </div>
	  </div>
	<div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Sobre nosotros</h4>
              <p style="color:white">Somos un equipo el cual esta cargo de toda la comunidad que le guste cocinar. esta proyecto se ha echo con la finalidad de que todos vosotros aprendamos a cocinar facil, rico y saludable. </p>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Enlaces rápidos</h4>
              <li><a href="recetas.php">Comida</a></li>
              <li><a href="#">Snacks</a></li>
              <li><a href="contacto.php">Contacto</a></li>
              <li><a href="reglas.php">Reglas de comunidad</a></li>
            </ul>
          </div>
         
          <div class="col-md-4">
            <ul class="footer_box">
              <h4>Visita nuestro canal de YouTube</h4>
              <p style="color:white">Para disfrutar de multiples recetas que les ayudaran a mejorar en la cocina.</p>
              <li><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured">Click para ir al canal</a></li>
              <ul class="social"> 
                <li class="facebook"><a href="#"><span> </span></a></li>
                <li class="twitter"><a href="#"><span> </span></a></li>
                <li class="instagram"><a href="#"><span> </span></a></li> 
                <li class="pinterest"><a href="#"><span> </span></a></li> 
                <li class="youtube"><a href="https://www.youtube.com/channel/UCIMyMv5jAxy2dPLswZjYL3w/featured"><span> </span></a></li>                             
                </ul>
                
            </ul>
          </div>
        </div>
        <div class="row footer_bottom">
            <div class="copy">
                 <p>© 2020 Template by <a href="https://www.facebook.com/javier.landa.96343" target="_blank">LANDITA</a></p>
                </div>
            
          </div>
      </div>
    </div>

</body>	
</html>